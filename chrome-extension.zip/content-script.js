// Stadia Style Content Script
(function() {
    'use strict';

    console.log('🎮 Stadia Style content script loaded!');

    let isStadiaEnabled = false;
    let isInitialized = false;

    // Check if extension is enabled for this site
    function checkExtensionState() {
        console.log('🔍 Checking extension state...');
        try {
            chrome.storage.sync.get(['stadiaEnabled'], function(result) {
                if (chrome.runtime.lastError) {
                    console.error('❌ Storage error:', chrome.runtime.lastError.message);
                    return;
                }
                isStadiaEnabled = result.stadiaEnabled !== false; // Default to enabled
                console.log('📊 Extension state:', isStadiaEnabled ? 'ENABLED' : 'DISABLED');
                applyStadiaStyle();
            });
        } catch (error) {
            console.error('❌ Error checking extension state:', error);
        }
    }

    // Apply or remove Stadia styling
    function applyStadiaStyle() {
        console.log('🎨 Applying Stadia style, enabled:', isStadiaEnabled);
        try {
            if (isStadiaEnabled) {
                document.body.classList.add('stadia-enabled');
                console.log('✅ Added stadia-enabled class to body');
                enhanceElements();
            } else {
                document.body.classList.remove('stadia-enabled');
                console.log('❌ Removed stadia-enabled class from body');
                removeEnhancements();
            }
        } catch (error) {
            console.error('❌ Error applying style:', error);
        }
    }

    // Enhanced elements detection and styling
    function enhanceElements() {
        console.log('🔧 Enhancing elements...');
        
        try {
            // Add glow effect to important buttons
            const importantButtons = document.querySelectorAll(
                'button[type="submit"], .cta-button, .primary-button, .main-button, .call-to-action'
            );
            console.log('🔘 Found', importantButtons.length, 'important buttons');
            importantButtons.forEach(btn => {
                btn.classList.add('glow-effect');
            });

            // Enhance form containers
            const forms = document.querySelectorAll('form');
            console.log('📝 Found', forms.length, 'forms');
            forms.forEach(form => {
                form.style.background = 'var(--stadia-dark-gray)';
                form.style.borderRadius = '12px';
                form.style.padding = '20px';
                form.style.border = '1px solid var(--stadia-warm-gray)';
            });

            // Enhance images with subtle borders
            const images = document.querySelectorAll('img');
            console.log('🖼️ Found', images.length, 'images');
            images.forEach(img => {
                img.style.borderRadius = '8px';
                img.style.border = '1px solid var(--stadia-warm-gray)';
                img.style.transition = 'all 0.3s ease';
            });

            // Add special handling for navigation menus
            const navMenus = document.querySelectorAll('ul.nav, .navigation, .main-menu');
            console.log('🧭 Found', navMenus.length, 'navigation menus');
            navMenus.forEach(menu => {
                menu.style.background = 'var(--stadia-gradient-main)';
                menu.style.borderRadius = '8px';
                menu.style.padding = '10px';
            });

            // Detect and style social media elements
            const socialElements = document.querySelectorAll(
                '.social, .share, [class*="facebook"], [class*="twitter"], [class*="instagram"], [class*="youtube"]'
            );
            console.log('📱 Found', socialElements.length, 'social media elements');
            socialElements.forEach(element => {
                element.style.background = 'var(--stadia-gradient-subtle)';
                element.style.borderRadius = '6px';
                element.style.padding = '8px';
            });

            console.log('✅ Element enhancement complete!');
        } catch (error) {
            console.error('❌ Error enhancing elements:', error);
        }
    }

    // Remove enhancements
    function removeEnhancements() {
        console.log('🧹 Removing enhancements...');
        
        try {
            const glowElements = document.querySelectorAll('.glow-effect');
            console.log('✨ Removing glow from', glowElements.length, 'elements');
            glowElements.forEach(element => {
                element.classList.remove('glow-effect');
            });

            // Reset inline styles (basic cleanup)
            const styledElements = document.querySelectorAll('[style*="--stadia"]');
            console.log('🎨 Removing inline styles from', styledElements.length, 'elements');
            styledElements.forEach(element => {
                element.removeAttribute('style');
            });
        } catch (error) {
            console.error('❌ Error removing enhancements:', error);
        }
    }

    // Listen for messages from popup
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        console.log('📨 Received message:', request);
        try {
            if (request.action === 'toggleStadia') {
                isStadiaEnabled = request.enabled;
                console.log('🔄 Toggling Stadia to:', isStadiaEnabled ? 'ENABLED' : 'DISABLED');
                chrome.storage.sync.set({stadiaEnabled: isStadiaEnabled}, function() {
                    if (chrome.runtime.lastError) {
                        console.error('❌ Storage error:', chrome.runtime.lastError.message);
                    }
                });
                applyStadiaStyle();
                sendResponse({success: true});
            } else if (request.action === 'getStatus') {
                console.log('📋 Status requested, current state:', isStadiaEnabled);
                sendResponse({enabled: isStadiaEnabled});
            }
        } catch (error) {
            console.error('❌ Error handling message:', error);
            sendResponse({success: false, error: error.message});
        }
        
        // Return true to indicate we will send a response asynchronously
        return true;
    });

    // Observe DOM changes for dynamic content
    let observer;
    
    function setupObserver() {
        try {
            observer = new MutationObserver(function(mutations) {
                if (isStadiaEnabled) {
                    mutations.forEach(function(mutation) {
                        if (mutation.type === 'childList') {
                            mutation.addedNodes.forEach(function(node) {
                                if (node.nodeType === Node.ELEMENT_NODE) {
                                    // Apply styling to new elements
                                    enhanceNewElement(node);
                                }
                            });
                        }
                    });
                }
            });

            if (document.body) {
                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
                console.log('👁️ DOM observer setup complete');
            }
        } catch (error) {
            console.error('❌ Error setting up observer:', error);
        }
    }

    // Enhance newly added elements
    function enhanceNewElement(element) {
        try {
            // Apply Stadia styling to new buttons
            const newButtons = element.querySelectorAll ? 
                element.querySelectorAll('button, .btn, input[type="submit"]') : 
                (element.matches && element.matches('button, .btn, input[type="submit"]') ? [element] : []);
            
            newButtons.forEach(btn => {
                if (btn.classList.contains('primary') || btn.classList.contains('cta')) {
                    btn.classList.add('glow-effect');
                }
            });

            // Apply styling to new form elements
            const newInputs = element.querySelectorAll ? 
                element.querySelectorAll('input, textarea, select') : 
                (element.matches && element.matches('input, textarea, select') ? [element] : []);
            
            newInputs.forEach(input => {
                input.style.background = 'var(--stadia-dark-gray)';
                input.style.color = 'var(--stadia-white)';
                input.style.border = '2px solid var(--stadia-warm-gray)';
                input.style.borderRadius = '6px';
            });
        } catch (error) {
            console.error('❌ Error enhancing new element:', error);
        }
    }

    // Initialize function
    function initialize() {
        if (isInitialized) return;
        
        console.log('🚀 Initializing Stadia Style extension...');
        checkExtensionState();
        setupObserver();
        isInitialized = true;
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        console.log('⏳ DOM is loading, waiting for DOMContentLoaded...');
        document.addEventListener('DOMContentLoaded', function() {
            console.log('✅ DOM loaded, initializing extension...');
            initialize();
        });
    } else {
        console.log('✅ DOM already loaded, initializing extension immediately...');
        initialize();
    }

    // Handle page visibility changes
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden && isStadiaEnabled && isInitialized) {
            console.log('👁️ Page became visible, reapplying enhancements...');
            // Reapply enhancements when page becomes visible
            setTimeout(enhanceElements, 100);
        }
    });

    console.log('🚀 Stadia Style content script initialization complete!');

})(); 