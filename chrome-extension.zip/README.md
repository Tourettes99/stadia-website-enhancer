# Stadia Style Chrome Extension

Transform any website with Google Stadia's iconic orange and purple gradient color scheme! This Chrome extension brings the beautiful and distinctive Stadia UI aesthetic to any website you visit.

## ✨ Features

- **Authentic Stadia Colors**: Uses the exact orange (#FF6D01) and purple (#9146FF) colors from Google Stadia
- **Stunning Gradients**: Signature orange-to-purple gradients that fade and merge seamlessly
- **Smart Styling**: Intelligently applies colors to common web elements without breaking functionality
- **Toggle Control**: Easy on/off toggle via the extension popup
- **Dynamic Content**: Automatically styles new content as it loads
- **Beautiful UI**: The extension popup itself showcases the Stadia design language

## 🎨 Color Palette

- **Primary Orange**: `#FF6D01`
- **Primary Purple**: `#9146FF`
- **Dark Purple**: `#5B2C87`
- **Warm Gray**: `#8B5A3C`
- **Dark Background**: `#1A1A1A`
- **White Text**: `#FFFFFF`

## 🚀 Installation

### Method 1: Load as Unpacked Extension (Developer Mode)

1. **Enable Developer Mode** in Chrome:
   - Open Chrome and go to `chrome://extensions/`
   - Toggle "Developer mode" in the top right corner

2. **Load the Extension**:
   - Click "Load unpacked"
   - Select the folder containing these extension files
   - The extension should appear in your extensions list

3. **Pin the Extension** (Optional):
   - Click the puzzle piece icon in Chrome's toolbar
   - Find "Stadia Style" and click the pin icon

### Method 2: Install from Chrome Web Store
*Coming soon! This extension will be submitted to the Chrome Web Store.*

## 🎮 How to Use

1. **Navigate** to any website
2. **Click** the Stadia Style extension icon in your toolbar
3. **Toggle** the switch to enable/disable the Stadia styling
4. **Enjoy** the beautiful transformation!

## 🌐 What Gets Styled

The extension intelligently applies Stadia colors to:

- **Headers** (H1-H6) - Get gradient text effects
- **Navigation bars** - Orange-purple gradient backgrounds
- **Buttons** - Stadia gradient with hover effects
- **Links** - Orange color with purple hover states
- **Forms** - Dark styling with orange focus states
- **Cards & Content blocks** - Dark backgrounds with warm borders
- **Tables** - Gradient headers and alternating row colors
- **Scrollbars** - Custom gradient styling
- **Code blocks** - Orange syntax highlighting
- **Images** - Subtle border styling

## ⚙️ Technical Details

- **Manifest Version**: 3 (latest Chrome extension standard)
- **Permissions**: `activeTab`, `storage`
- **Content Scripts**: Automatically inject on all websites
- **Popup Interface**: Toggle and status controls
- **Storage**: Remembers your preference across sessions

## 🔧 File Structure

```
chrome-extension/
├── manifest.json          # Extension configuration
├── stadia-styles.css      # Main CSS styling
├── content-script.js      # Content injection script
├── popup.html            # Extension popup interface
├── popup-styles.css      # Popup styling
├── popup-script.js       # Popup functionality
├── icons/                # Extension icons
└── README.md             # This file
```

## 🎯 Compatibility

- **Chrome**: Version 88+
- **Edge**: Chromium-based versions
- **Websites**: Works on all HTTP/HTTPS websites
- **Responsive**: Adapts to mobile and desktop layouts

## 🛠️ Development

To modify or enhance the extension:

1. Edit the CSS in `stadia-styles.css` for styling changes
2. Modify `content-script.js` for behavior changes
3. Update `popup.html` and related files for UI changes
4. Reload the extension in `chrome://extensions/` after changes

## 🐛 Troubleshooting

- **Extension not working**: Try refreshing the webpage after enabling
- **Some elements not styled**: Some websites use very specific CSS that might override the styling
- **Performance issues**: The extension is lightweight, but try disabling on heavy websites if needed

## 🎨 Design Philosophy

This extension aims to:
- Maintain website functionality while enhancing aesthetics
- Use authentic Stadia colors and gradients
- Provide a cohesive visual experience across all websites
- Respect user preferences with easy toggle control

## 📜 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Contributions are welcome! Feel free to:
- Report bugs
- Suggest new features
- Submit pull requests
- Improve documentation

## 🎉 Enjoy!

Transform your browsing experience with the beautiful colors that made Google Stadia's interface so distinctive. Every website becomes a part of the Stadia universe!

---

*Made with ❤️ for Stadia fans and beautiful web design* 