// 🔍 Stadia Extension Diagnostic Script
// Copy and paste this entire code into the browser console on any website

console.log('🧪 Starting Stadia Extension Diagnostics...');

// Test 1: Check if content script loaded
function test1_ContentScript() {
    console.log('\n📋 TEST 1: Content Script Loading');
    const hasContentScript = window.chrome && chrome.runtime && chrome.runtime.onMessage;
    console.log('Chrome APIs available:', hasContentScript);
    
    // Look for extension-related console messages
    console.log('Look above for messages starting with 🎮');
    return hasContentScript;
}

// Test 2: Check CSS injection
function test2_CSSInjection() {
    console.log('\n📋 TEST 2: CSS Injection');
    const orangeColor = getComputedStyle(document.documentElement).getPropertyValue('--stadia-orange');
    const purpleColor = getComputedStyle(document.documentElement).getPropertyValue('--stadia-purple');
    
    console.log('Orange color variable:', orangeColor.trim() || 'NOT FOUND');
    console.log('Purple color variable:', purpleColor.trim() || 'NOT FOUND');
    
    return orangeColor.trim() === '#FF6D01';
}

// Test 3: Check body class
function test3_BodyClass() {
    console.log('\n📋 TEST 3: Body Class');
    const hasClass = document.body.classList.contains('stadia-enabled');
    console.log('Body has stadia-enabled class:', hasClass);
    
    if (!hasClass) {
        console.log('❌ Extension is not active or not working');
    } else {
        console.log('✅ Extension is active');
    }
    
    return hasClass;
}

// Test 4: Manual CSS application
function test4_ManualCSS() {
    console.log('\n📋 TEST 4: Manual CSS Test');
    
    // Add the class manually
    document.body.classList.add('stadia-enabled');
    console.log('✅ Added stadia-enabled class manually');
    
    // Wait a moment, then check if styling applies
    setTimeout(() => {
        const bodyBg = getComputedStyle(document.body).backgroundColor;
        const isStadiaColors = bodyBg.includes('26, 26, 26') || bodyBg.includes('rgb(26, 26, 26)');
        
        console.log('Body background color:', bodyBg);
        console.log('Has Stadia dark background:', isStadiaColors);
        
        if (isStadiaColors) {
            console.log('✅ CSS is working! Extension should work.');
        } else {
            console.log('❌ CSS not applying. Possible issues:');
            console.log('   - CSS file not loaded');
            console.log('   - Website overriding styles');
            console.log('   - CSS syntax error');
        }
    }, 500);
}

// Test 5: Force header styling
function test5_ForceHeaders() {
    console.log('\n📋 TEST 5: Force Header Styling');
    
    const headers = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
    console.log(`Found ${headers.length} headers`);
    
    if (headers.length > 0) {
        headers.forEach((header, index) => {
            header.style.background = 'linear-gradient(135deg, #FF6D01 0%, #9146FF 100%)';
            header.style.webkitBackgroundClip = 'text';
            header.style.webkitTextFillColor = 'transparent';
            header.style.fontWeight = 'bold';
        });
        console.log('✅ Applied gradient to headers manually');
        console.log('📝 If headers now have orange-purple gradient, CSS works!');
    } else {
        console.log('⚠️ No headers found on this page');
    }
}

// Run all tests
function runAllTests() {
    console.log('🎮 STADIA EXTENSION DIAGNOSTIC REPORT');
    console.log('=====================================');
    
    const results = {
        contentScript: test1_ContentScript(),
        cssInjection: test2_CSSInjection(),
        bodyClass: test3_BodyClass()
    };
    
    test4_ManualCSS();
    test5_ForceHeaders();
    
    console.log('\n📊 SUMMARY:');
    console.log('Content Script:', results.contentScript ? '✅' : '❌');
    console.log('CSS Variables:', results.cssInjection ? '✅' : '❌');
    console.log('Body Class:', results.bodyClass ? '✅' : '❌');
    
    if (!results.contentScript && !results.cssInjection) {
        console.log('\n🚨 DIAGNOSIS: Extension not loading at all');
        console.log('💡 SOLUTION: Check chrome://extensions/ - reload extension');
    } else if (results.contentScript && !results.cssInjection) {
        console.log('\n🚨 DIAGNOSIS: Content script works but CSS not loading');
        console.log('💡 SOLUTION: Check stadia-styles.css file exists and has no errors');
    } else if (!results.bodyClass) {
        console.log('\n🚨 DIAGNOSIS: Extension loaded but not active');
        console.log('💡 SOLUTION: Click extension icon and toggle it on');
    } else {
        console.log('\n✅ DIAGNOSIS: Extension should be working!');
        console.log('📝 If you don\'t see changes, the website might be overriding styles');
    }
    
    return results;
}

// Run the diagnostic
runAllTests(); 