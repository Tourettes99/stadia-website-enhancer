// Background Service Worker for Stadia Style Extension
chrome.runtime.onInstalled.addListener(function(details) {
    if (details.reason === 'install') {
        // Set default state on installation
        chrome.storage.sync.set({stadiaEnabled: true});
        
        // Set initial badge
        chrome.action.setBadgeText({text: 'ON'});
        chrome.action.setBadgeBackgroundColor({color: '#FF6D01'});
        
        // Optional: Open a welcome page
        // chrome.tabs.create({url: 'https://example.com/welcome'});
    }
});

// Handle extension icon click when no popup is defined
chrome.action.onClicked.addListener(function(tab) {
    // This won't be called since we have a popup, but keeping for completeness
    chrome.storage.sync.get(['stadiaEnabled'], function(result) {
        const newState = !result.stadiaEnabled;
        chrome.storage.sync.set({stadiaEnabled: newState});
        
        chrome.tabs.sendMessage(tab.id, {
            action: 'toggleStadia',
            enabled: newState
        });
    });
});

// Listen for tab updates to refresh badge if needed
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete') {
        chrome.storage.sync.get(['stadiaEnabled'], function(result) {
            const isEnabled = result.stadiaEnabled !== false;
            chrome.action.setBadgeText({
                text: isEnabled ? 'ON' : '',
                tabId: tabId
            });
            chrome.action.setBadgeBackgroundColor({
                color: isEnabled ? '#FF6D01' : '#999999',
                tabId: tabId
            });
        });
    }
}); 