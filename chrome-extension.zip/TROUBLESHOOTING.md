# 🔧 Troubleshooting Guide - Stadia Style Extension

If your extension isn't applying changes to websites, follow these debugging steps:

## ✅ **Step 1: Verify Extension Installation**

1. **Check Extensions Page**:
   - Go to `chrome://extensions/`
   - Make sure "Stadia Style" appears in the list
   - Ensure it's **ENABLED** (toggle switch should be blue/on)
   - Look for any error messages in red

2. **Check Developer Mode**:
   - Developer mode should be **ON** (toggle in top-right)
   - If you see errors, click "Errors" to view details

## 🧪 **Step 2: Test on Simple Page**

1. **Open the test page**:
   - In your file manager, double-click `debug-test.html`
   - This will open it in your browser as `file:///...`

2. **Check if styling applies**:
   - The page should transform when you toggle the extension
   - Headers should have orange-purple gradient text
   - Background should turn dark
   - Buttons should have gradient styling

## 🔍 **Step 3: Check Console Messages**

1. **Open Developer Tools**:
   - Press `F12` or right-click → "Inspect"
   - Go to the **Console** tab

2. **Look for extension messages**:
   - You should see messages starting with 🎮, 🔍, 📊, etc.
   - **If you see NO messages**: Content script isn't loading
   - **If you see error messages**: There's a code issue

3. **Expected console output**:
   ```
   🎮 Stadia Style content script loaded!
   🔍 Checking extension state...
   📊 Extension state: ENABLED
   🎨 Applying Stadia style, enabled: true
   ✅ Added stadia-enabled class to body
   🔧 Enhancing elements...
   ```

## 🔄 **Step 4: Test Extension Toggle**

1. **Click the extension icon** in your toolbar
2. **Try toggling** the switch on/off
3. **Check console** for toggle messages:
   ```
   📨 Received message: {action: "toggleStadia", enabled: true}
   🔄 Toggling Stadia to: ENABLED
   ```

## ⚠️ **Common Issues & Fixes**

### Issue: "Extension not visible in toolbar"
**Fix**: 
- Click the puzzle piece icon (extensions menu)
- Find "Stadia Style" and click the pin icon

### Issue: "No console messages appear"
**Fix**: 
- Go to `chrome://extensions/`
- Find "Stadia Style" and click the **refresh/reload** button
- Refresh the webpage you're testing on

### Issue: "Content script errors"
**Fix**:
- Check if all files are in the correct location
- Make sure `manifest.json`, `content-script.js`, and `stadia-styles.css` exist
- Reload the extension

### Issue: "CSS not applying"
**Fix**:
- Check if `body.stadia-enabled` class is added to the page
- In console, type: `document.body.classList.contains('stadia-enabled')`
- Should return `true` when extension is active

### Issue: "Works on test page but not other sites"
**Possible causes**:
- Some websites override CSS with `!important` rules
- Content Security Policy might block the extension
- Website uses Shadow DOM or iframes

## 🧪 **Step 5: Manual Testing Commands**

Open console on any webpage and try these commands:

```javascript
// Check if extension loaded
console.log('Extension class present:', document.body.classList.contains('stadia-enabled'));

// Manually add the class to test CSS
document.body.classList.add('stadia-enabled');

// Check if CSS variables are available
console.log('Orange color:', getComputedStyle(document.documentElement).getPropertyValue('--stadia-orange'));

// Test if extension responds to messages
chrome.runtime.sendMessage({action: 'getStatus'}, response => console.log('Status:', response));
```

## 🔧 **Step 6: Force Extension Refresh**

1. Go to `chrome://extensions/`
2. Click the **refresh button** on Stadia Style extension
3. Refresh any open webpages
4. Try the extension again

## 📊 **Step 7: Check Permissions**

The extension should have:
- ✅ **Read and change data on all websites**
- ✅ **Storage** permission

If missing, the extension might not have proper permissions.

## 🆘 **If Nothing Works**

1. **Completely remove** the extension
2. **Reload** the folder in Chrome
3. Test on a simple site like `example.com`
4. Check if Chrome is up to date
5. Try in **Incognito mode** (allow the extension in incognito first)

## ✅ **Success Indicators**

When working correctly, you should see:
- 🎮 Console messages from the extension
- `stadia-enabled` class on `<body>` element
- Visual changes: dark background, orange/purple gradients
- Extension popup shows "Active" status

---

**Still having issues?** The extension includes detailed console logging to help identify exactly where the problem occurs. 