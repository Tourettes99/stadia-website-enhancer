# Quick Installation Guide

## Load the Extension in Chrome

1. **Open Chrome** and navigate to: `chrome://extensions/`

2. **Enable Developer Mode** by toggling the switch in the top-right corner

3. **Click "Load unpacked"** button

4. **Select this folder** (`chrome-extension`) that contains all the extension files

5. **The extension should now appear** in your extensions list with the name "Stadia Style"

6. **Pin the extension** (optional):
   - Click the puzzle piece icon in Chrome's toolbar
   - Find "Stadia Style" and click the pin icon to keep it visible

## Test the Extension

1. **Visit any website** (try Wikipedia, GitHub, or any news site)
2. **Click the Stadia Style icon** in your toolbar
3. **Toggle the switch** to enable Stadia styling
4. **Watch the magic happen!** The website should transform with orange and purple gradients

## Icon Files Note

The extension references icon files in the `icons/` folder:
- `icon16.png` (16x16 pixels)
- `icon48.png` (48x48 pixels) 
- `icon128.png` (128x128 pixels)

You can create these icons using any image editor, or download Stadia-themed icons online. The extension will work without them, but Chrome will show default icons.

## Troubleshooting

- If the extension doesn't load, check that all files are in the correct location
- If styling doesn't apply, try refreshing the webpage after enabling the extension
- Make sure you've enabled the extension toggle in the popup

## Enjoy!

Your Chrome extension is ready to transform the web with Stadia's beautiful color scheme! 🎮✨ 