// Popup Script for Stadia Style Extension
document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.getElementById('stadiaToggle');
    const toggleLabel = document.getElementById('toggleLabel');
    const statusDot = document.querySelector('.status-dot');
    const statusText = document.getElementById('statusText');
    const popupContainer = document.querySelector('.popup-container');

    // Initialize popup state
    chrome.storage.sync.get(['stadiaEnabled'], function(result) {
        const isEnabled = result.stadiaEnabled !== false; // Default to enabled
        updateUI(isEnabled);
    });

    // Handle toggle change
    toggle.addEventListener('change', function() {
        const isEnabled = toggle.checked;
        
        // Add activation animation
        popupContainer.classList.add('activated');
        setTimeout(() => popupContainer.classList.remove('activated'), 600);
        
        // Save state
        chrome.storage.sync.set({stadiaEnabled: isEnabled});
        
        // Send message to content script with proper error handling
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'toggleStadia',
                    enabled: isEnabled
                }, function(response) {
                    if (chrome.runtime.lastError) {
                        // Content script not available - this is normal for some pages
                        console.log('Content script not available:', chrome.runtime.lastError.message);
                    } else {
                        console.log('Toggle message sent successfully');
                    }
                });
            }
        });
        
        updateUI(isEnabled);
        
        // Provide user feedback
        showStatusMessage(isEnabled ? 'Stadia Style Activated!' : 'Stadia Style Disabled');
    });

    function updateUI(isEnabled) {
        toggle.checked = isEnabled;
        
        if (isEnabled) {
            toggleLabel.textContent = 'Disable Stadia Style';
            statusDot.className = 'status-dot active';
            statusText.textContent = 'Active';
        } else {
            toggleLabel.textContent = 'Enable Stadia Style';
            statusDot.className = 'status-dot inactive';
            statusText.textContent = 'Inactive';
        }
    }

    function showStatusMessage(message) {
        const originalText = statusText.textContent;
        statusText.textContent = message;
        statusDot.className = 'status-dot';
        
        setTimeout(() => {
            statusText.textContent = originalText;
            statusDot.className = toggle.checked ? 'status-dot active' : 'status-dot inactive';
        }, 2000);
    }

    // Check current tab's extension status with proper error handling
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {action: 'getStatus'}, function(response) {
                if (chrome.runtime.lastError) {
                    // Content script not available - use stored state instead
                    console.log('Content script not available, using stored state:', chrome.runtime.lastError.message);
                    chrome.storage.sync.get(['stadiaEnabled'], function(result) {
                        const isEnabled = result.stadiaEnabled !== false;
                        updateUI(isEnabled);
                    });
                } else if (response && typeof response.enabled === 'boolean') {
                    updateUI(response.enabled);
                }
            });
        }
    });

    // Add hover effects to color samples
    const colorSamples = document.querySelectorAll('.color-sample');
    colorSamples.forEach(sample => {
        sample.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
            this.style.boxShadow = '0 4px 12px rgba(255, 109, 1, 0.4)';
        });
        
        sample.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
            this.style.boxShadow = 'none';
        });
    });

    // Easter egg: Click on Stadia icon for special effect
    const stadiaIcon = document.querySelector('.stadia-icon');
    stadiaIcon.addEventListener('click', function() {
        popupContainer.style.animation = 'stadiaActivation 0.6s ease-out';
        setTimeout(() => {
            popupContainer.style.animation = '';
        }, 600);
        
        // Temporary gradient animation on the icon
        this.style.background = 'linear-gradient(45deg, #FF6D01, #9146FF)';
        this.style.animation = 'spin 1s ease-in-out';
        
        setTimeout(() => {
            this.style.background = '#FFFFFF';
            this.style.animation = '';
        }, 1000);
    });

    // Add spin animation for easter egg
    const style = document.createElement('style');
    style.textContent = `
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);

    // Handle extension icon badge
    function updateBadge(isEnabled) {
        chrome.action.setBadgeText({
            text: isEnabled ? 'ON' : ''
        });
        chrome.action.setBadgeBackgroundColor({
            color: isEnabled ? '#FF6D01' : '#999999'
        });
    }

    // Update badge when toggle changes
    toggle.addEventListener('change', function() {
        updateBadge(toggle.checked);
    });

    // Initialize badge
    chrome.storage.sync.get(['stadiaEnabled'], function(result) {
        updateBadge(result.stadiaEnabled !== false);
    });
}); 