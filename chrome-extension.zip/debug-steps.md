# 🔍 Debug: Extension Not Applying Colors

## Step 1: Check Extension Status

1. **Go to** `chrome://extensions/`
2. **Find "Stadia Style"** - is it:
   - ✅ **Enabled** (toggle switch is blue)
   - ✅ **No errors** shown in red text
   - ✅ Shows "Inspect views: popup.html" (not grayed out)

3. **Check permissions**:
   - Should show: "Can read and change data on all websites you visit"
   - If not, the extension lacks permissions

## Step 2: Test the Debug Page

1. **Open** `debug-test.html` (double-click the file)
2. **Press F12** → Console tab
3. **Look for these messages**:
   ```
   🎮 Stadia Style content script loaded!
   🔍 Checking extension state...
   📊 Extension state: ENABLED
   ✅ Added stadia-enabled class to body
   ```

**Result:**
- ✅ **See messages**: Content script is working
- ❌ **No messages**: Content script not loading

## Step 3: Manual CSS Test

**In the console of any website, type:**
```javascript
document.body.classList.add('stadia-enabled');
```

**Expected result:**
- ✅ **Page changes colors**: CSS is working
- ❌ **No change**: CSS not loading

## Step 4: Check CSS Variables

**In console, type:**
```javascript
console.log(getComputedStyle(document.documentElement).getPropertyValue('--stadia-orange'));
```

**Expected result:**
- ✅ **Shows "#FF6D01"**: CSS loaded
- ❌ **Shows empty or error**: CSS not loaded

## Step 5: Check Body Class

**In console, type:**
```javascript
console.log('Has stadia class:', document.body.classList.contains('stadia-enabled'));
```

**Expected result:**
- ✅ **"true"**: Extension applied class
- ❌ **"false"**: Extension not working

## Step 6: Force Extension Reset

If nothing above works:

1. **Remove extension**:
   - Go to `chrome://extensions/`
   - Click "Remove" on Stadia Style

2. **Reload extension**:
   - Click "Load unpacked"
   - Select your extension folder again

3. **Test again** on a simple website like `example.com`

## Common Issues:

### Issue A: "Content script not loading"
**Symptoms**: No console messages, no styling
**Solution**: 
- Check `manifest.json` for syntax errors
- Ensure `content-script.js` exists
- Check Chrome's error console in extensions page

### Issue B: "CSS not applying" 
**Symptoms**: Console messages appear, but no visual changes
**Solution**:
- Check if `stadia-styles.css` exists
- Verify CSS file has no syntax errors
- Some websites might override styles

### Issue C: "Extension has no permissions"
**Symptoms**: Works on test page but not real websites
**Solution**:
- Check permissions in `chrome://extensions/`
- Should show "Can read and change data on all websites"

## Quick Fix Commands:

**Test if CSS works manually:**
```javascript
// Add the class manually
document.body.classList.add('stadia-enabled');

// Check if variables exist
console.log('Orange:', getComputedStyle(document.documentElement).getPropertyValue('--stadia-orange'));

// Force header color
document.querySelectorAll('h1, h2, h3').forEach(h => {
    h.style.background = 'linear-gradient(135deg, #FF6D01 0%, #9146FF 100%)';
    h.style.webkitBackgroundClip = 'text';
    h.style.webkitTextFillColor = 'transparent';
});
```

---

**Run through these steps and tell me what you find!** 